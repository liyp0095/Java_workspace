
public class Edge {
	public int source;
	public int target;
	
	public Edge(int source, int target){
		this.source = source;
		this.target = target;
	}
}
